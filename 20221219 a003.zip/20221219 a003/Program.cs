﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _20221219_a003
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            int M = input [0];//輸入字串,變成int
            int M2 =input [1];//C#不能直接給值 月份有兩位數的,拆成三個輸入
            int D = input [2];
            int S = ((M+M2) * 2 + D) % 3;

            if(S==0)
            {
                Console.WriteLine("普通");
            }
            else if(S==1)
            {
                Console.WriteLine("吉");
            }
            else if(S==2)
            {
                Console.WriteLine("大吉");
            }

            Console.ReadLine();
        }
    }
}
