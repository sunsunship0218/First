﻿// a034.cpp : 此檔案包含 'main' 函式。程式會於該處開始執行及結束執行。
//

#include "pch.h"
#include <iostream>
using namespace std;

int main()
{
	int input, binary;
	int mod[100];//存餘數
	while(cin >> input)
	{
		binary = 0;
		while (input >=1)//除數不為0
		{
			mod[100] = input % 2;// 取餘數
			binary++;//進位1
			input =input/2;
				
		}
		for (int i = binary; i >= 0; i--)
		{
			cout << mod[i];
		}
		
		return 0;

	}
}

