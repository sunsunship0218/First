﻿// A022.cpp : 此檔案包含 'main' 函式。程式會於該處開始執行及結束執行。
//

#include "pch.h"
#include <iostream>

using namespace std;

int main() {
    string input;
    bool palindrome = false;//設置回文為0
    while (cin >> input)
    {
        //第一位從0開始 長度如果是五 陣列就會是四
        for (int i = 0; i < input.length(); i++) {
            if (input[i] == input[input.length() - 1 - i])//(減掉自己,植樹問題再減 相同的話是回文)
            {
                bool palindrome = true;
                cout << "yes" << endl;
                break;//要記得的離開迴圈
            }
            else
            {
                cout << "no" << endl;
                break;
            }
        }
        return 0;

    }

}
