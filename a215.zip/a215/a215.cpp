﻿// a215.cpp : 此檔案包含 'main' 函式。程式會於該處開始執行及結束執行。
//

#include "pch.h"
#include <iostream>
using namespace std;
int main() {
    int n, m, count;
    while (cin >> n >> m)
    {
        int sum = 0;
        int count = 0;
        for (int i = 0; ; i++)//公差為1的等差數列 ,找到+最後項>m後就停止(不知道項數範圍) i是公差
        {
            //n+(n+1)+(n+2)+....
            sum += n + i;//sum=sum+n+i
            count++;
            if (sum > m)//總和大於
            {
                cout << count << endl;//
                break;
            }
        }

    }


}
