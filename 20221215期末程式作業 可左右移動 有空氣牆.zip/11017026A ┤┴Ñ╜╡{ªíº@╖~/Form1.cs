using System.Windows.Forms;

namespace _11017026A_期末程式作業
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int ManNum;//紀錄統神的圖片駐標值
        bool ManMove ; //預設統神沒辦法使用鍵盤移動
        private void Form1_Load(object sender, EventArgs e)
        {
          
            //讓PictureBox可以調整大小
            PicRoad.SizeMode = PictureBoxSizeMode.StretchImage;
            PicRoadWhite.SizeMode = PictureBoxSizeMode.StretchImage;
            PicHidenRoad.SizeMode = PictureBoxSizeMode.StretchImage;
            PicHotPot.SizeMode= PictureBoxSizeMode.StretchImage;
            //載入圖像
            PicRoad.Image = new Bitmap(@"C:\Users\USER\OneDrive\圖片\SIDE project\期末素材圖檔\馬路.png");
            PicRoadWhite.Image = new Bitmap(@"C:\Users\USER\OneDrive\圖片\SIDE project\期末素材圖檔\馬路有白線.png");
            PicHidenRoad.Image=new Bitmap(@"C:\Users\USER\OneDrive\圖片\SIDE project\期末素材圖檔\馬路.png");//擋多出來的白線
            PicHotPot.Image = new Bitmap(@"C:\Users\USER\OneDrive\圖片\SIDE project\期末素材圖檔\鍋子.png");
            
           
            RoadAndGametimer1.Interval = 40;//0.05秒有白線的路動一次          
            ManTimer.Interval = 350;//秒統神轉一次


            ManMove = false;//預設一開始統神沒辦法使用鍵盤移動 
            
        }



        private void Gametimer1_Tick(object sender, EventArgs e)
        {                      
           PicRoadWhite.Top += 50;//PicRoadWhite.Top=PicRoadWhite.Top+50,只往下移動
            if (PicRoadWhite.Top >= 40)//移動到底的位置 約在y(40),
            {
                PicRoadWhite.Top = -500 - PicRoad.Top;
            }                     
        }
        private void ManTimer_Tick(object sender, EventArgs e)
        {
            PicMan.Image = ManImgList.Images[ManNum];

            
            
                if (ManNum == 0)//一開始在0
                {
                    ManNum = 1;//如果是0就到下張1
                }
                else
                {
                    ManNum = 0;//!=0(就等於1,因為只有兩張)的話是0
                }
            
            
                 
                

        }
        private void BtnStart_KeyDown(object sender, KeyEventArgs e)
        {
            int ManSpeed = 15;//預設統神速度15
            if(ManMove == true)
            {   //道路視窗範圍34-400           
                //按A往右,同時加上最右到34的判斷,超過就不繼續往右
                if (e.KeyCode == Keys.A && PicMan.Left>34)
                {
                    PicMan.Left -= ManSpeed;
                }
                //按D往左,以及同時加上最低往左到400的判斷
                if (e.KeyCode == Keys.D && PicMan.Left<402)
                {
                    PicMan.Left += ManSpeed;
                }
                if(PicMan.Width<=26 || PicMan.Width >= 400)
                {
                    PicMan.Left += 0;
                }                                                             
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            RoadAndGametimer1.Start();//路跟遊戲計時器,按下按鈕才開始
            ManTimer.Start();
            ManMove = true;
        }

       


        //按到的,刪了介面會消失
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {

        }

        private void PicLine2_Click(object sender, EventArgs e)
        {

        }

        private void PicRoadWhite_Click(object sender, EventArgs e)
        {

        }

      
    }
}