using System.Diagnostics.Metrics;
using System.Media;
using System.Numerics;
using System.Windows.Forms;

namespace _11017026A_期末程式作業
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int ManNum;//紀錄統神的圖片駐標值
        bool ManMove ; //預設統神沒辦法使用鍵盤移動
        int meters = 0;//預設公尺數=0;
        //背景音樂全域變數
        //撞到音樂全域變數
        System.Media.SoundPlayer Bg_Music = new SoundPlayer(@"C:\Users\USER\Music\遊戲\[AKIRA]超跑情人夢.wav");
        System.Media.SoundPlayer Collision_Music = new SoundPlayer(@"C:\Users\USER\Music\遊戲\統神端火鍋.wav");
        //碰撞音效姻緣不合法
        private void Form1_Load(object sender, EventArgs e)
        {         
            //讓PictureBox可以調整大小
            PicRoad.SizeMode = PictureBoxSizeMode.StretchImage;
            PicRoadWhite.SizeMode = PictureBoxSizeMode.StretchImage;
            PicHidenRoad.SizeMode = PictureBoxSizeMode.StretchImage;
            PicHotPot.SizeMode= PictureBoxSizeMode.StretchImage;
            PicHotPot2.SizeMode = PictureBoxSizeMode.StretchImage;
            //載入圖像
            PicRoad.Image = new Bitmap(@"C:\Users\USER\OneDrive\圖片\SIDE project\期末素材圖檔\馬路.png");
            PicRoadWhite.Image = new Bitmap(@"C:\Users\USER\OneDrive\圖片\SIDE project\期末素材圖檔\馬路有白線.png");
            PicHidenRoad.Image=new Bitmap(@"C:\Users\USER\OneDrive\圖片\SIDE project\期末素材圖檔\馬路.png");//擋多出來的白線
            PicHotPot.Image = new Bitmap(@"C:\Users\USER\OneDrive\圖片\SIDE project\期末素材圖檔\鍋子測試.png");
            PicHotPot2.Image = new Bitmap(@"C:\Users\USER\OneDrive\圖片\SIDE project\期末素材圖檔\鍋子測試.png");

            RoadAndGametimer1.Interval = 40;//0.05秒有白線的路動一次          
            ManTimer.Interval = 350;//350毫秒統神轉一次          

            ManMove = false;//預設一開始統神沒辦法使用鍵盤移動                        
            LblMeters.Visible = false;//未按開始看不到標籤
            //按下開始前看不到火鍋
            PicHotPot.Visible = false;
            PicHotPot2.Visible = false;

            PicGameOver.SizeMode = PictureBoxSizeMode.StretchImage;//GAME OVER 圖片
            PicGameOver.Image = new Bitmap(@"C:\Users\USER\OneDrive\圖片\SIDE project\期末素材圖檔\GAME OVER.png");
            PicGameOver.Visible = false;//預設看不到
            BtnRestart.Visible = false;
        }



        private void Gametimer1_Tick(object sender, EventArgs e)
        {            
            PicRoadWhite.Top += 50;//PicRoadWhite.Top=PicRoadWhite.Top+50,只往下移動
            if (PicRoadWhite.Top >= 110)//移動到底的位置 從頭開始
            {
                PicRoadWhite.Top = -500 - PicRoad.Top;
            }

            PicHotPot.Top += 13;
            PicHotPot2.Top += 20;
            Random HotPotPosition = new Random();
            if (PicHotPot.Top >= 444)//移動到底的位置 從頭開始
            {
                PicHotPot.Top = -500 - PicRoad.Top;
                PicHotPot.Left= HotPotPosition.Next(1,168);//x(26)-x(173)左右的位置隨機出現                
            }
           if( PicHotPot2.Top >= 444)
           {
                PicHotPot2.Top = -500 - PicRoad.Top;
                PicHotPot2.Left = HotPotPosition.Next(242 ,427);//左右的位置隨機出現
           }
           //統神與火鍋碰撞處理
           if(PicMan.Bounds.IntersectsWith(PicHotPot.Bounds)|| PicMan.Bounds.IntersectsWith(PicHotPot2.Bounds))
           {
                               
               
                ManTimer.Stop();
                RoadAndGametimer1.Stop();
                PicGameOver.Visible = true;//GAME OVER出現                                             
                Bg_Music.Stop();//音樂停止
                BtnRestart.Visible = true;//重新開始出現
            }
            else
            {                   //迴圈跑的快慢看這裡
                for (int i = 1; i < 1000; i+=100)//0.1秒跳一次計算
                {
                    meters += 1;
                }

            }
            LblMeters.Text = $"統神走了{meters}公尺";

           
        }
        private void ManTimer_Tick(object sender, EventArgs e)
        {
            PicMan.Image = ManImgList.Images[ManNum];

            if (ManNum == 0)//一開始在0
            {
                ManNum = 1;//如果是0就到下張1
            }
            else
            {
                ManNum = 0;//!=0(就等於1,因為只有兩張)的話是0
            }
        }

        private void BtnStart_KeyDown(object sender, KeyEventArgs e)
        {
            int ManSpeed = 25;//預設統神速度
            if(ManMove == true)
            {   //道路視窗範圍34-400           
                //按A往右,同時加上最右到34的判斷,超過就不繼續往右
                if (e.KeyCode == Keys.A && PicMan.Left>34)
                {
                    PicMan.Left -= ManSpeed;
                }
                //按D往左,以及同時加上最低往左到400的判斷
                if (e.KeyCode == Keys.D && PicMan.Left<402)
                {
                    PicMan.Left += ManSpeed;
                }
                if(PicMan.Width<=26 || PicMan.Width >= 400)
                {
                    PicMan.Left += 0;
                }                                                             
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            RoadAndGametimer1.Start();//路跟遊戲計時器,按下按鈕才開始
            ManTimer.Start();          
            ManMove = true;
            LblMeters.Visible = true;//顯示分數標籤
            //顯示火鍋
            PicHotPot.Visible = true;
            PicHotPot2.Visible = true;
            //按下按鈕 撥放背景音樂           
            Bg_Music.PlayLooping();
            //碰撞
            if (PicMan.Bounds.IntersectsWith(PicHotPot.Bounds)||PicMan.Bounds.IntersectsWith(PicHotPot2.Bounds))
            {
                RoadAndGametimer1.Stop();//路停止動
                ManTimer.Stop();//人停止動               
                ManMove = false;//統神不動
                Collision_Music.Play();//撞到鍋子播放一代一代
            }
           
        }

        private void BtnRestart_Click(object sender, EventArgs e)
        {
            //重置遊戲
            PicGameOver.Visible = false;//關閉Game over (O)
            PicHotPot.Visible = false;//關閉火鍋(O)
            PicHotPot2.Visible = false;//(O)
            PicMan.Left = 217;//統神回到原點 (O)
            //火鍋到最頂
            PicHotPot.Top = -17;//(0)
            PicHotPot2.Top = 3; //(0)          
            //關掉Restart

            //分數重置(0)
            meters = 0;
            LblMeters.Text = $"統神走了{meters}公尺";
            BtnRestart.Visible = false;//按下重新開始,關閉

            //換開始出現
            if (BtnRestart.Visible = false)//重新開始關的
            {
                BtnStart.Visible = true;//開始出現
            }           

        }


        //按到的,刪了介面會消失
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {

        }

        private void PicLine2_Click(object sender, EventArgs e)
        {

        }

        private void PicRoadWhite_Click(object sender, EventArgs e)
        {

        }

        private void PicHotPot_Click(object sender, EventArgs e)
        {

        }

        private void PicRoad_Click(object sender, EventArgs e)
        {

        }

        private void PicHotPot2_Click(object sender, EventArgs e)
        {

        }
    }
}