﻿namespace _11017026A_期末程式作業
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.PicRoad = new System.Windows.Forms.PictureBox();
            this.PicMan = new System.Windows.Forms.PictureBox();
            this.RoadAndGametimer1 = new System.Windows.Forms.Timer(this.components);
            this.PicRoadWhite = new System.Windows.Forms.PictureBox();
            this.PicHidenRoad = new System.Windows.Forms.PictureBox();
            this.BtnStart = new System.Windows.Forms.Button();
            this.ManImgList = new System.Windows.Forms.ImageList(this.components);
            this.ManTimer = new System.Windows.Forms.Timer(this.components);
            this.PicHotPot = new System.Windows.Forms.PictureBox();
            this.PicHotPot2 = new System.Windows.Forms.PictureBox();
            this.LblMeters = new System.Windows.Forms.Label();
            this.PicGameOver = new System.Windows.Forms.PictureBox();
            this.BtnRestart = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.PicRoad)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicMan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicRoadWhite)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicHidenRoad)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicHotPot)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicHotPot2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicGameOver)).BeginInit();
            this.SuspendLayout();
            // 
            // PicRoad
            // 
            this.PicRoad.Image = global::_11017026A_期末程式作業.Properties.Resources.馬路;
            this.PicRoad.Location = new System.Drawing.Point(1, -93);
            this.PicRoad.Name = "PicRoad";
            this.PicRoad.Size = new System.Drawing.Size(551, 673);
            this.PicRoad.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PicRoad.TabIndex = 0;
            this.PicRoad.TabStop = false;
            this.PicRoad.Click += new System.EventHandler(this.PicRoad_Click);
            // 
            // PicMan
            // 
            this.PicMan.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.PicMan.BackgroundImage = global::_11017026A_期末程式作業.Properties.Resources.馬路有白線;
            this.PicMan.Image = global::_11017026A_期末程式作業.Properties.Resources.統神端火鍋0;
            this.PicMan.Location = new System.Drawing.Point(217, 444);
            this.PicMan.Name = "PicMan";
            this.PicMan.Size = new System.Drawing.Size(103, 136);
            this.PicMan.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PicMan.TabIndex = 2;
            this.PicMan.TabStop = false;
            // 
            // RoadAndGametimer1
            // 
            this.RoadAndGametimer1.Interval = 20;
            this.RoadAndGametimer1.Tick += new System.EventHandler(this.Gametimer1_Tick);
            // 
            // PicRoadWhite
            // 
            this.PicRoadWhite.BackColor = System.Drawing.SystemColors.Control;
            this.PicRoadWhite.Image = global::_11017026A_期末程式作業.Properties.Resources.馬路有白線;
            this.PicRoadWhite.InitialImage = global::_11017026A_期末程式作業.Properties.Resources.馬路有白線;
            this.PicRoadWhite.Location = new System.Drawing.Point(91, 53);
            this.PicRoadWhite.Name = "PicRoadWhite";
            this.PicRoadWhite.Size = new System.Drawing.Size(348, 456);
            this.PicRoadWhite.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PicRoadWhite.TabIndex = 3;
            this.PicRoadWhite.TabStop = false;
            this.PicRoadWhite.Tag = "line";
            this.PicRoadWhite.Click += new System.EventHandler(this.PicRoadWhite_Click);
            // 
            // PicHidenRoad
            // 
            this.PicHidenRoad.Image = global::_11017026A_期末程式作業.Properties.Resources.馬路;
            this.PicHidenRoad.Location = new System.Drawing.Point(1, 578);
            this.PicHidenRoad.Name = "PicHidenRoad";
            this.PicHidenRoad.Size = new System.Drawing.Size(551, 27);
            this.PicHidenRoad.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PicHidenRoad.TabIndex = 4;
            this.PicHidenRoad.TabStop = false;
            // 
            // BtnStart
            // 
            this.BtnStart.BackColor = System.Drawing.Color.Firebrick;
            this.BtnStart.Font = new System.Drawing.Font("Stencil", 19.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            this.BtnStart.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BtnStart.Location = new System.Drawing.Point(147, 611);
            this.BtnStart.Name = "BtnStart";
            this.BtnStart.Size = new System.Drawing.Size(252, 66);
            this.BtnStart.TabIndex = 5;
            this.BtnStart.Text = "S T A R T";
            this.BtnStart.UseVisualStyleBackColor = false;
            this.BtnStart.Click += new System.EventHandler(this.button1_Click);
            this.BtnStart.KeyDown += new System.Windows.Forms.KeyEventHandler(this.BtnStart_KeyDown);
            // 
            // ManImgList
            // 
            this.ManImgList.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.ManImgList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ManImgList.ImageStream")));
            this.ManImgList.TransparentColor = System.Drawing.Color.Transparent;
            this.ManImgList.Images.SetKeyName(0, "統神端火鍋0.png");
            this.ManImgList.Images.SetKeyName(1, "統神端火鍋1.png");
            // 
            // ManTimer
            // 
            this.ManTimer.Tick += new System.EventHandler(this.ManTimer_Tick);
            // 
            // PicHotPot
            // 
            this.PicHotPot.ErrorImage = global::_11017026A_期末程式作業.Properties.Resources.鍋子1;
            this.PicHotPot.Image = global::_11017026A_期末程式作業.Properties.Resources.鍋子;
            this.PicHotPot.InitialImage = global::_11017026A_期末程式作業.Properties.Resources.鍋子;
            this.PicHotPot.Location = new System.Drawing.Point(121, -17);
            this.PicHotPot.Name = "PicHotPot";
            this.PicHotPot.Size = new System.Drawing.Size(95, 111);
            this.PicHotPot.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PicHotPot.TabIndex = 6;
            this.PicHotPot.TabStop = false;
            this.PicHotPot.Click += new System.EventHandler(this.PicHotPot_Click);
            // 
            // PicHotPot2
            // 
            this.PicHotPot2.ErrorImage = global::_11017026A_期末程式作業.Properties.Resources.鍋子1;
            this.PicHotPot2.Image = global::_11017026A_期末程式作業.Properties.Resources.鍋子;
            this.PicHotPot2.InitialImage = global::_11017026A_期末程式作業.Properties.Resources.鍋子;
            this.PicHotPot2.Location = new System.Drawing.Point(413, 3);
            this.PicHotPot2.Name = "PicHotPot2";
            this.PicHotPot2.Size = new System.Drawing.Size(72, 91);
            this.PicHotPot2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PicHotPot2.TabIndex = 7;
            this.PicHotPot2.TabStop = false;
            this.PicHotPot2.Click += new System.EventHandler(this.PicHotPot2_Click);
            // 
            // LblMeters
            // 
            this.LblMeters.AutoSize = true;
            this.LblMeters.Font = new System.Drawing.Font("Microsoft JhengHei UI", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.LblMeters.Location = new System.Drawing.Point(153, 694);
            this.LblMeters.Name = "LblMeters";
            this.LblMeters.Size = new System.Drawing.Size(158, 42);
            this.LblMeters.TabIndex = 8;
            this.LblMeters.Text = "統神走了:";
            // 
            // PicGameOver
            // 
            this.PicGameOver.ErrorImage = global::_11017026A_期末程式作業.Properties.Resources.GAME_OVER;
            this.PicGameOver.Image = global::_11017026A_期末程式作業.Properties.Resources.GAME_OVER;
            this.PicGameOver.InitialImage = global::_11017026A_期末程式作業.Properties.Resources.GAME_OVER;
            this.PicGameOver.Location = new System.Drawing.Point(121, 235);
            this.PicGameOver.Name = "PicGameOver";
            this.PicGameOver.Size = new System.Drawing.Size(278, 101);
            this.PicGameOver.TabIndex = 10;
            this.PicGameOver.TabStop = false;
            // 
            // BtnRestart
            // 
            this.BtnRestart.BackColor = System.Drawing.Color.Firebrick;
            this.BtnRestart.Font = new System.Drawing.Font("Stencil", 19.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            this.BtnRestart.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BtnRestart.Location = new System.Drawing.Point(147, 611);
            this.BtnRestart.Name = "BtnRestart";
            this.BtnRestart.Size = new System.Drawing.Size(252, 66);
            this.BtnRestart.TabIndex = 11;
            this.BtnRestart.Text = "R E S T A R T";
            this.BtnRestart.UseVisualStyleBackColor = false;
            this.BtnRestart.Click += new System.EventHandler(this.BtnRestart_Click);
            this.BtnRestart.KeyDown += new System.Windows.Forms.KeyEventHandler(this.BtnStart_KeyDown);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(552, 786);
            this.Controls.Add(this.BtnRestart);
            this.Controls.Add(this.PicGameOver);
            this.Controls.Add(this.PicHotPot2);
            this.Controls.Add(this.PicHotPot);
            this.Controls.Add(this.PicMan);
            this.Controls.Add(this.LblMeters);
            this.Controls.Add(this.BtnStart);
            this.Controls.Add(this.PicHidenRoad);
            this.Controls.Add(this.PicRoadWhite);
            this.Controls.Add(this.PicRoad);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Name = "Form1";
            this.Tag = "";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.PicRoad)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicMan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicRoadWhite)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicHidenRoad)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicHotPot)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicHotPot2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicGameOver)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private PictureBox PicRoad;
        private PictureBox PicMan;
        private System.Windows.Forms.Timer RoadAndGametimer1;
        private PictureBox PicRoadWhite;
        private PictureBox PicHidenRoad;
        private Button BtnStart;
        private ImageList ManImgList;
        private System.Windows.Forms.Timer ManTimer;
        private PictureBox PicHotPot;
        private PictureBox PicHotPot2;
        private Label LblMeters;
        private PictureBox PicGameOver;
        private Button BtnRestart;
    }
}