﻿// a065.cpp : 此檔案包含 'main' 函式。程式會於該處開始執行及結束執行。
//

#include "pch.h"
#include <iostream>
using namespace std;
int main()
{
    char P, O, K, E, M, I, N;//輸入字元順序
    cin >> P >> O >> K >> E >> M >> I >> N;//給值
    cout << abs(O - P) << abs(K - O) << abs(E - K) << abs(M - E) << abs(I - M) << abs(N - I) << endl;//少分號 (i+1)-i位置
    return 0;
}


