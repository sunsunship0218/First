﻿// a058.cpp : 此檔案包含 'main' 函式。程式會於該處開始執行及結束執行。
//

#include "pch.h"
#include <iostream>
using namespace std;
int main()
{
    int input,mod0,mod1,mod2,amount;
    mod0 = 0, mod1 = 0, mod2 = 0;
    cin >> input;//值給input
    for (int i = 1; i <= input ; i++)//除數不為0,範圍不大於輸入
    {
        cin >> amount;
        if (amount % 3 == 0)//0
        {
            mod0++;
        }
        else if (amount % 3 == 1)//1
        {
            mod1++;
        }
        else if(amount % 3 == 2)//2
        {
            mod2++;
        }       
    }
      cout << mod0 << " " << mod1 << " " << mod2 << endl;//輸出要放在迴圈外
}

