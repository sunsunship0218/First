﻿// a034.cpp : 此檔案包含 'main' 函式。程式會於該處開始執行及結束執行。
//

#include "pch.h"
#include <iostream>
using namespace std;
int main()
{
	int input, binary;
	int mod[100];//存每次的餘數1
	while(cin >> input)
	{
		binary = 0;//進入迴圈之前,binaery就必須歸0一次,如果宣告的時候就將binary=0,下次進入迴圈時,binary不會清除上次所處存的值
		while (input >=1)//除數不為0
		{
			mod[binary] = input % 2;// 取餘數1,然後存起來
			binary++;//進位1
			input /= 2;
		}
		for (int i = binary-1; i >= 0; i--)//4的話是100, 最低的輸出是0開始 ,從儲存最高位印到最低位
		{
			cout << mod[i];//輸出並印出 
		}		
		cout << endl;//換行
	}
	return 0;
}
//可以用Stack解決,學後要回來重寫一次

