﻿// a009.cpp : 此檔案包含 'main' 函式。程式會於該處開始執行及結束執行。
//

#include "pch.h"
#include <iostream>
#include<string>
using namespace std;

int main()
{
	string encrypt;	
	while (getline(cin, encrypt))//讀入整行
	{
		int k = 7;
		/*
		在encrypt的範圍內,跑完for迴圈後,char decrypt會存放結果,類型最後是char 
		
		for (int i = 0; i < encrypt.length(); i++)
		{
			char decrypt = encrypt[i];//取出字串中的第i字元
			decrypt -= k;
			cout << decrypt;
		}
		
		範圍型的for迴圈 每次跑for迴圈的時候會自動從encrypt取出一個字元並存在decrypt中,所以直接-就好
		*/
		for (char decrypt : encrypt)
		{
			decrypt -= k;//secrypt=decrypt-k			
			cout << decrypt;
		}		
	}
	 
}


