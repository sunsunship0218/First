﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace a149_20221229
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
           int test = 0;
           string input= Console.ReadLine();
            for(int j=0;j<input.Length;j++)
            {
                test = Convert.ToInt32(input[j] - 48);//ASCII要減48
                Console.WriteLine(test);
            }
           
           
           
           

            Console.ReadLine();
        }
    }
}
