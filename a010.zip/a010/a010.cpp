﻿// a010.cpp : 此檔案包含 'main' 函式。程式會於該處開始執行及結束執行。
//

#include "pch.h"
#include <iostream>
using namespace std;
//是否是質數 是的話直接輸出
//如果不是質數 除到不能除 且因數由小寫到大
//因數次方大於一 ,以指數型式輸出
//避免重複輸出*
int main()
{
	int input;
	cin >> input;
	int times;//次方
	for (int i = 2; i <= input; i++)//因為只能被1除就是質數,迴圈從2開始
	{
		times = 0;//次方一開始是0

		while (input % i == 0)//目前因數能整除就繼續,直到不能整除,會i++,前往下個能整除的因數
		{
			input /= i;//input=input/i;
			times++;//次方+1
						
		}
		if (times > 0)//這個判斷可以避免輸出重複的* 如果出現多次方的因數 也不會重複印出*
		{
			if (times == 1)//一次方的話直接輸出因數i
			{
				cout << i;
			}
			else if (times > 1)//次方大於1的狀況,顯示指數
			{
				cout <<i << "^" << times ;// 2^3*5  2的三次方
			}
			if (input >1 )//有剩下的質因數,輸出*
			{
				cout << " * ";

			}
		}				
	}
	if (input > 1)//最後剩下的質因數,直接輸出(最後一個質因數)
	{
		cout << input;

	}
}

