namespace _11017026A_期末程式作業
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //讓PictureBox可以調整大小
            PicRoad.SizeMode = PictureBoxSizeMode.StretchImage;
            PicRoadWhite.SizeMode = PictureBoxSizeMode.StretchImage;
            PicHidenRoad.SizeMode = PictureBoxSizeMode.StretchImage;

            //載入圖像
            PicRoad.Image = new Bitmap(@"C:\Users\USER\OneDrive\圖片\SIDE project\期末素材圖檔\馬路.png");
            PicRoadWhite.Image = new Bitmap(@"C:\Users\USER\OneDrive\圖片\SIDE project\期末素材圖檔\馬路有白線.png");
            PicHidenRoad.Image=new Bitmap(@"C:\Users\USER\OneDrive\圖片\SIDE project\期末素材圖檔\馬路.png");//擋多出來的白線


           
            RoadAndGametimer1.Interval = 50;//0.1秒有白線的路動一次
        }



        private void Gametimer1_Tick(object sender, EventArgs e)
        {                      
                PicRoadWhite.Top += 50;//PicRoadWhite.Top=PicRoadWhite.Top-50,只往上移動
                if (PicRoadWhite.Top >= 40)//移動到底的位置 約在y(-535),
                {
                    PicRoadWhite.Top = -500 - PicRoad.Top;
                }                     
        }

        private void button1_Click(object sender, EventArgs e)
        {
            RoadAndGametimer1.Start();//路跟遊戲計時器按下按鈕開始

        }



        //按到的,刪了介面會消失
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {

        }

        private void PicLine2_Click(object sender, EventArgs e)
        {

        }

        private void PicRoadWhite_Click(object sender, EventArgs e)
        {

        }

       
    }
}