﻿namespace _11017026A_期末程式作業
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.PicRoad = new System.Windows.Forms.PictureBox();
            this.PicPeople = new System.Windows.Forms.PictureBox();
            this.RoadAndGametimer1 = new System.Windows.Forms.Timer(this.components);
            this.PicRoadWhite = new System.Windows.Forms.PictureBox();
            this.PicHidenRoad = new System.Windows.Forms.PictureBox();
            this.BtnStart = new System.Windows.Forms.Button();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.PicRoad)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicPeople)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicRoadWhite)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicHidenRoad)).BeginInit();
            this.SuspendLayout();
            // 
            // PicRoad
            // 
            this.PicRoad.Location = new System.Drawing.Point(26, -97);
            this.PicRoad.Name = "PicRoad";
            this.PicRoad.Size = new System.Drawing.Size(486, 673);
            this.PicRoad.TabIndex = 0;
            this.PicRoad.TabStop = false;
            // 
            // PicPeople
            // 
            this.PicPeople.Location = new System.Drawing.Point(562, 292);
            this.PicPeople.Name = "PicPeople";
            this.PicPeople.Size = new System.Drawing.Size(104, 132);
            this.PicPeople.TabIndex = 2;
            this.PicPeople.TabStop = false;
            // 
            // RoadAndGametimer1
            // 
            this.RoadAndGametimer1.Interval = 20;
            this.RoadAndGametimer1.Tick += new System.EventHandler(this.Gametimer1_Tick);
            // 
            // PicRoadWhite
            // 
            this.PicRoadWhite.Location = new System.Drawing.Point(67, -87);
            this.PicRoadWhite.Name = "PicRoadWhite";
            this.PicRoadWhite.Size = new System.Drawing.Size(388, 619);
            this.PicRoadWhite.TabIndex = 3;
            this.PicRoadWhite.TabStop = false;
            this.PicRoadWhite.Tag = "line";
            this.PicRoadWhite.Click += new System.EventHandler(this.PicRoadWhite_Click);
            // 
            // PicHidenRoad
            // 
            this.PicHidenRoad.Location = new System.Drawing.Point(26, 575);
            this.PicHidenRoad.Name = "PicHidenRoad";
            this.PicHidenRoad.Size = new System.Drawing.Size(486, 55);
            this.PicHidenRoad.TabIndex = 4;
            this.PicHidenRoad.TabStop = false;
            // 
            // BtnStart
            // 
            this.BtnStart.BackColor = System.Drawing.Color.Firebrick;
            this.BtnStart.Font = new System.Drawing.Font("Stencil", 19.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            this.BtnStart.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BtnStart.Location = new System.Drawing.Point(140, 665);
            this.BtnStart.Name = "BtnStart";
            this.BtnStart.Size = new System.Drawing.Size(252, 66);
            this.BtnStart.TabIndex = 5;
            this.BtnStart.Text = "S T A R T";
            this.BtnStart.UseVisualStyleBackColor = false;
            this.BtnStart.Click += new System.EventHandler(this.button1_Click);
            // 
            // imageList1
            // 
            this.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imageList1.ImageSize = new System.Drawing.Size(16, 16);
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(797, 786);
            this.Controls.Add(this.BtnStart);
            this.Controls.Add(this.PicHidenRoad);
            this.Controls.Add(this.PicRoadWhite);
            this.Controls.Add(this.PicRoad);
            this.Controls.Add(this.PicPeople);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Name = "Form1";
            this.Tag = "";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.PicRoad)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicPeople)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicRoadWhite)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicHidenRoad)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private PictureBox PicRoad;
        private PictureBox PicPeople;
        private System.Windows.Forms.Timer RoadAndGametimer1;
        private PictureBox PicRoadWhite;
        private PictureBox PicHidenRoad;
        private Button BtnStart;
        private ImageList imageList1;
    }
}